<?php
$flag = '0xGame{session_un5eria1ize}';


