<?php

$dbusername = 'www-data';

$dbpassword = '';

$database = 'user';