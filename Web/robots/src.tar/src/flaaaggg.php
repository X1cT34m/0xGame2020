<?php
$flag = '0xGame{now_you_k0nw_robots_Protocol}';
echo $flag;
?>
