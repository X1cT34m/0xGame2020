<!DOCTYPE>
<html>
<head>
<meta charset="utf-8">
<title>robots协议</title>
</head>
<body>
<h1 align='center'>What is robots protocol?</h1>
<a href='https://www.baidu.com/'>点击这里了解一下</a>
</body>
</html>
